Given(/^I am on the first screen$/) do
  element_exists("view")
  sleep(STEP_PAUSE)
end