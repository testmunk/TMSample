Given /^I am on the first screen$/ do
  wait_for_element_exists('view')
  sleep(3)
end